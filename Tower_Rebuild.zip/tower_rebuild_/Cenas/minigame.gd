extends Control

@onready var pergunta = $LabelPergunta
@onready var resposta = $LineEditResposta
@onready var botao = $ButtonEnviar
@onready var label_tempo = $LabelTimer
@onready var label_tentativas = $LabelTentativa

var resposta_correta = 0
var pergunta_atual = ""

var tempo = 30
var tentativas = 3

func _ready():

	randomize()

	gerar_questao()

	botao.pressed.connect(_verificar_resposta)

	iniciar_timer()


func iniciar_timer():

	while tempo > 0:

		label_tempo.text = "Tempo: " + str(tempo)

		await get_tree().create_timer(1.0).timeout

		tempo -= 1

	
	get_tree().change_scene_to_file("res://Cenas/game_over.tscn")


func gerar_questao():

	label_tentativas.text = "Tentativas: " + str(tentativas)

	var tipo = randi() % 6

	var a
	var b
	var c

	match tipo:

		0:
			a = randi_range(20, 100)
			b = randi_range(20, 100)

			pergunta_atual = "%d + %d = ?" % [a, b]
			resposta_correta = a + b

		1:
			a = randi_range(50, 150)
			b = randi_range(10, 80)

			if b > a:
				var temp = a
				a = b
				b = temp

			pergunta_atual = "%d - %d = ?" % [a, b]
			resposta_correta = a - b

		2:
			a = randi_range(6, 12)
			b = randi_range(6, 12)

			pergunta_atual = "%d × %d = ?" % [a, b]
			resposta_correta = a * b

		3:
			b = randi_range(2, 12)
			resposta_correta = randi_range(2, 12)
			a = b * resposta_correta

			pergunta_atual = "%d ÷ %d = ?" % [a, b]

		4:
			a = randi_range(1, 20)
			b = randi_range(1, 20)
			c = randi_range(1, 10)

			pergunta_atual = "%d + %d × %d = ?" % [a, b, c]
			resposta_correta = a + (b * c)

		5:
			a = randi_range(1, 15)
			b = randi_range(1, 15)
			c = randi_range(1, 10)

			pergunta_atual = "(%d + %d) × %d = ?" % [a, b, c]
			resposta_correta = (a + b) * c

	pergunta.text = pergunta_atual
	resposta.text = ""


func _verificar_resposta():

	if resposta.text.is_valid_int():

		var valor = int(resposta.text)

		
		if valor == resposta_correta:

			Global.minigame_concluido = true

			if not Global.placa_atual in Global.placas_concluidas:
				Global.placas_concluidas.append(Global.placa_atual)

			await get_tree().create_timer(0.5).timeout

			get_tree().change_scene_to_file("res://Cenas/main.tscn")

		
		else:

			tentativas -= 1

			
			if tentativas <= 0:
				get_tree().change_scene_to_file("res://Cenas/game_over.tscn")

			else:
				gerar_questao()
