extends Area2D

@onready var player = $player


func _ready() -> void:

	
	if Global.voltar_do_minigame:
		player.global_position = Global.ultima_posicao_player
		Global.voltar_do_minigame = false

	
	mostrar_fumacas()

	
	if Global.placas_concluidas.size() >= 10:

		await get_tree().create_timer(1.0).timeout

		get_tree().change_scene_to_file("res://Cenas/game_win.tscn")


func _process(delta: float) -> void:
	pass


func mostrar_fumacas():

	for placa in Global.placas_concluidas:

		match placa:

			"placa_porta1":
				$Fumacas/fumaca1.visible = true

			"placa_porta2":
				$Fumacas/fumaca2.visible = true

			"placa_porta3":
				$Fumacas/fumaca3.visible = true

			"placa_porta4":
				$Fumacas/fumaca4.visible = true

			"placa_porta5":
				$Fumacas/fumaca5.visible = true

			"placa_porta6":
				$Fumacas/fumaca6.visible = true

			"placa_porta7":
				$Fumacas/fumaca7.visible = true

			"placa_porta8":
				$Fumacas/fumaca8.visible = true

			"placa_porta9":
				$Fumacas/fumaca9.visible = true

			"placa_porta10":
				$Fumacas/fumaca10.visible = true
