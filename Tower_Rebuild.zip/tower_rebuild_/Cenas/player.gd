extends CharacterBody2D

@export var speed = 130
@onready var sprite = $AnimatedSprite2D

var last_direction = Vector2.DOWN

func _physics_process(delta):

	var direction = Vector2.ZERO

	
	direction.x = Input.get_axis("ui_left", "ui_right")
	direction.y = Input.get_axis("ui_up", "ui_down")

	velocity = direction.normalized() * speed
	move_and_slide()

	animar(direction)

	var encostando_placa = false

	
	for i in range(get_slide_collision_count()):

		var collision = get_slide_collision(i)
		var objeto = collision.get_collider()

		if objeto != null and objeto.is_in_group("placa_porta"):
			encostando_placa = true

	
	if encostando_placa and Input.is_action_just_pressed("interagir"):

		Global.ultima_posicao_player = global_position
		Global.voltar_do_minigame = true

		
		var placa_mais_perto = ""
		var menor_distancia = 999999

		for placa in get_parent().get_node("colisoesPlaca").get_children():

			if placa is CollisionShape2D:

				var distancia = global_position.distance_to(placa.global_position)

				if distancia < menor_distancia:
					menor_distancia = distancia
					placa_mais_perto = placa.name

		Global.placa_atual = placa_mais_perto

		
		if not placa_mais_perto in Global.placas_concluidas:
			get_tree().change_scene_to_file("res://Cenas/minigame.tscn")


func animar(direction):

	
	if direction == Vector2.ZERO:

		if last_direction == Vector2.DOWN:
			sprite.play("idle")

		elif last_direction == Vector2.UP:
			sprite.play("idle_back")

		else:
			sprite.play("idle_side")
			sprite.flip_h = last_direction.x > 0

		return

	last_direction = direction

	
	if abs(direction.x) > abs(direction.y):

		sprite.play("run_side")
		sprite.flip_h = direction.x > 0

	
	elif direction.y < 0:

		sprite.play("run_back")

	
	else:

		sprite.play("run")
