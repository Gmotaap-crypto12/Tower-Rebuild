extends Node

@onready var label = $Label

var texto = "Use os Botoes ⬆️ para ir para
cima, ⬅️ para a esquerda, ➞
para a direita, ⬇️ para baixo
e espaco para selecionar a 
placa/porta."
var velocidade = 0.3  

func _ready():
	label.text = ""
	mostrar_texto()

func mostrar_texto():
	var palavras = texto.split(" ")
	
	for palavra in palavras:
		label.text += palavra + " "
		await get_tree().create_timer(velocidade).timeout








func _on_button_pressed() -> void:
	get_tree().change_scene_to_file("res://Cenas/main.tscn")
