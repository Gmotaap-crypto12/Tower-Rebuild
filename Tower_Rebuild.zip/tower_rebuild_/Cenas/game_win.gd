extends Node

@onready var label = $Label

var texto = "Apos anos longe de casa, Joao finalmente conseguiu salvar sua cidade
natal. Com esforco, coragem e tudo o que aprendeu em sua jornada, ele
reconstruiu cada rua, cada predio e devolveu esperanca aos moradores.

A cidade estava viva novamente.
E Joao finalmente podia chamar aquele lugar de lar outra vez."
var velocidade = 0.3  

func _ready():
	label.text = ""
	mostrar_texto()

func mostrar_texto():
	var palavras = texto.split(" ")
	
	for palavra in palavras:
		label.text += palavra + " "
		await get_tree().create_timer(velocidade).timeout








func _on_button_pressed() -> void:
	get_tree().change_scene_to_file("res://Cenas/Inicio.tscn")
