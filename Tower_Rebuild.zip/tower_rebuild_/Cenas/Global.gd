extends Node

var minigame_concluido = false

var ultima_posicao_player = Vector2.ZERO

var voltar_do_minigame = false

var placa_atual = ""

var placas_concluidas = []


func resetar_jogo():

	minigame_concluido = false

	ultima_posicao_player = Vector2.ZERO

	voltar_do_minigame = false

	placa_atual = ""

	placas_concluidas.clear()
