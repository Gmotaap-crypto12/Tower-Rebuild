extends Node

@onready var label = $Label

var texto = "Joao era um construtor que havia deixado sua cidade natal em busca de
seus sonhos.  Porem, um tornado acabou  destruindo ela, ele deve
retornar a ela para colocar em pratica tudo o que aprendeu
anteriormente."
var velocidade = 0.3  

func _ready():
	label.text = ""
	mostrar_texto()

func mostrar_texto():
	var palavras = texto.split(" ")
	
	for palavra in palavras:
		label.text += palavra + " "
		await get_tree().create_timer(velocidade).timeout
















func _on_button_pressed() -> void:
	get_tree().change_scene_to_file("res://Cenas/tutorial.tscn")
