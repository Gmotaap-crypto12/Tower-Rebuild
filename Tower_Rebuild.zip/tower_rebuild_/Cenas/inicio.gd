extends Node



func _on_button_pressed() -> void:
	Global.resetar_jogo()

	get_tree().change_scene_to_file("res://Cenas/introdução.tscn")
